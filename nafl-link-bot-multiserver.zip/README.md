# NAFL LINK — Multi-server starter

This starter registers global slash commands `/verfie` and `/setup-verfie`.

## Important
- Each server admin with **Manage Roles** runs `/setup-verfie` and selects the role to grant.
- Members then use `/verfie` and sign in through Roblox's official OAuth page.
- The bot never asks for a Roblox password.
- **This is a starter, not production-ready.** Per-server role settings and linked-account checks are held in memory and are lost when the process restarts. Use persistent database storage and security review before public launch.
- A publicly reachable HTTPS host is required for Roblox OAuth callback. This cannot be completed using only a local Windows PC.
- Never share `DISCORD_TOKEN` or `ROBLOX_CLIENT_SECRET`.

## Setup
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and fill in your Discord bot token, application ID, Roblox OAuth client ID/secret, and public HTTPS URLs.
3. In Roblox Creator Dashboard OAuth app, register exactly `https://YOUR-DOMAIN/oauth/roblox/callback`.
4. In Discord Developer Portal, install settings should allow Guild Install and the `applications.commands` scope. Invite the bot with `bot` and `applications.commands`, plus **Manage Roles** permission.
5. Make sure the bot's highest role is above the role that each server wants to assign.
6. In this folder run:
   ```powershell
   npm install
   npm run deploy
   npm start
   ```
7. In each Discord server, an admin runs `/setup-verfie` and chooses the role. Members use `/verfie`.

Commands are registered globally and may take a little while to appear in Discord.
