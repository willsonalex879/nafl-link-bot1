require("dotenv").config();
const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");

for (const key of ["DISCORD_TOKEN", "DISCORD_CLIENT_ID"]) {
  if (!process.env[key]) throw new Error(`Missing ${key} in .env`);
}

const commands = [
  new SlashCommandBuilder()
    .setName("verfie")
    .setDescription("Get a secure Roblox verification button."),
  new SlashCommandBuilder()
    .setName("setup-verfie")
    .setDescription("Choose the role given after Roblox verification in this server.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addRoleOption(option =>
      option.setName("role")
        .setDescription("Role to give after verification (for example: verf player)")
        .setRequired(true))
].map(command => command.toJSON());

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
(async () => {
  // Global commands make the bot usable in every server it is invited to.
  await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands });
  console.log("Registered global /verfie and /setup-verfie commands.");
})().catch(err => {
  console.error("Failed to register slash commands:", err);
  process.exit(1);
});
