require("dotenv").config();
const crypto = require("node:crypto");
const express = require("express");
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, Client, EmbedBuilder,
  Events, GatewayIntentBits, PermissionFlagsBits
} = require("discord.js");

const ENV_KEYS = ["DISCORD_TOKEN", "DISCORD_CLIENT_ID", "ROBLOX_CLIENT_ID",
  "ROBLOX_CLIENT_SECRET", "BASE_URL", "ROBLOX_REDIRECT_URI"];
for (const key of ENV_KEYS) {
  if (!process.env[key]) {
    console.error(`Missing ${key}. Copy .env.example to .env and fill it in.`);
    process.exit(1);
  }
}
const app = express();
const port = Number(process.env.PORT || 3000);
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

// Starter configuration is kept in memory; a restart clears it.
// Add a database before using this as a large public service.
const guildRoleConfig = new Map();
const pending = new Map();
const linkedRoblox = new Map();
const STATE_TTL_MS = 10 * 60 * 1000;
setInterval(() => {
  const now = Date.now();
  for (const [state, item] of pending) if (item.createdAt < now - STATE_TTL_MS) pending.delete(state);
}, 60_000).unref();

function esc(s) {
  return String(s).replace(/[&<>"]/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;" }[c]));
}
function page(title, message, success = false) {
  const accent = success ? "#39e58c" : "#f0bf55";
  return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} · NAFL LINK</title>
  <style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#090a0c;color:#f5f5f5;font-family:system-ui;padding:22px}.card{width:min(560px,100%);border:1px solid #333;border-radius:24px;background:#15171b;padding:34px}.brand{color:#f0bf55;letter-spacing:.15em;font-weight:900;font-size:13px}h1{font-size:32px}p{color:#c0c2c8;line-height:1.7}.pill{color:${accent};border:1px solid ${accent};border-radius:99px;padding:7px 12px;font-size:12px}</style>
  <main class="card"><div class="brand">NAFL HUB · LINK</div><p class="pill">${success ? "VERIFICATION COMPLETE" : "ACCOUNT VERIFICATION"}</p><h1>${esc(title)}</h1><p>${esc(message)}</p><p>Secure Roblox OAuth · Never share your password</p></main></html>`;
}
app.get("/", (_req, res) => res.type("html").send(page("Connect Roblox", "Open Discord and use /verfie in a server where NAFL LINK is installed.")));

app.get("/verify", (req, res) => {
  const state = String(req.query.state || "");
  const item = pending.get(state);
  if (!item || item.createdAt < Date.now() - STATE_TTL_MS) {
    return res.status(400).type("html").send(page("Link expired", "Return to Discord and run /verfie again."));
  }
  const url = new URL("https://apis.roblox.com/oauth/v1/authorize");
  url.searchParams.set("client_id", process.env.ROBLOX_CLIENT_ID);
  url.searchParams.set("redirect_uri", process.env.ROBLOX_REDIRECT_URI);
  url.searchParams.set("scope", "openid profile");
  url.searchParams.set("response_type", "code");
  url.searchParams.set("state", state);
  url.searchParams.set("prompt", "select_account");
  res.redirect(url.toString());
});

app.get("/oauth/roblox/callback", async (req, res) => {
  const state = String(req.query.state || "");
  const code = String(req.query.code || "");
  const item = pending.get(state);
  if (!item || item.createdAt < Date.now() - STATE_TTL_MS) {
    return res.status(400).type("html").send(page("Link expired", "Return to Discord and run /verfie again."));
  }
  pending.delete(state);
  if (req.query.error || !code) return res.status(400).type("html").send(page("Verification cancelled", "No role was changed. Return to Discord and try again."));
  try {
    const form = new URLSearchParams({
      client_id: process.env.ROBLOX_CLIENT_ID,
      client_secret: process.env.ROBLOX_CLIENT_SECRET,
      grant_type: "authorization_code",
      code,
      redirect_uri: process.env.ROBLOX_REDIRECT_URI
    });
    const tokenResponse = await fetch("https://apis.roblox.com/oauth/v1/token", {
      method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form
    });
    if (!tokenResponse.ok) throw new Error(`Roblox token exchange failed (${tokenResponse.status})`);
    const tokenData = await tokenResponse.json();
    const userResponse = await fetch("https://apis.roblox.com/oauth/v1/userinfo", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    if (!userResponse.ok) throw new Error(`Roblox userinfo failed (${userResponse.status})`);
    const roblox = await userResponse.json();
    if (!roblox.sub || !roblox.preferred_username) throw new Error("Roblox profile missing.");

    const guild = await client.guilds.fetch(item.guildId);
    const member = await guild.members.fetch(item.discordUserId);
    const roleId = guildRoleConfig.get(item.guildId);
    if (!roleId) throw new Error("This server has not run /setup-verfie.");
    const role = await guild.roles.fetch(roleId);
    if (!role) throw new Error("Configured role was not found.");
    const botMember = await guild.members.fetchMe();
    if (role.managed || role.position >= botMember.roles.highest.position) {
      throw new Error("Move the bot's role above the verification role in Server Settings > Roles.");
    }
    const previous = linkedRoblox.get(String(roblox.sub));
    if (previous && previous.discordUserId !== item.discordUserId) {
      return res.status(409).type("html").send(page("Account already linked", "This Roblox account is already linked to another Discord user."));
    }
    await member.roles.add(role, `NAFL LINK: Roblox account verified (${roblox.preferred_username})`);
    linkedRoblox.set(String(roblox.sub), { discordUserId: item.discordUserId, guildId: item.guildId });
    return res.type("html").send(page("You're verified!", `Roblox account ${roblox.preferred_username} was verified in ${guild.name}. Return to Discord.`, true));
  } catch (err) {
    console.error("OAuth callback error:", err.message);
    return res.status(500).type("html").send(page("Couldn't finish verification", "Check the bot's permissions, the server setup, and OAuth configuration, then run /verfie again."));
  }
});

client.once(Events.ClientReady, readyClient => {
  console.log(`NAFL LINK online as ${readyClient.user.tag}`);
  app.listen(port, () => console.log(`Verification web server listening on port ${port}`));
});
client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  if (!interaction.inGuild()) return interaction.reply({ content: "Use this command inside a Discord server.", ephemeral: true });

  if (interaction.commandName === "setup-verfie") {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({ content: "You need Manage Roles permission to configure verification.", ephemeral: true });
    }
    const role = interaction.options.getRole("role", true);
    const botMember = await interaction.guild.members.fetchMe();
    if (role.managed || role.position >= botMember.roles.highest.position) {
      return interaction.reply({ content: "Move the bot's role above that role in Server Settings → Roles, then run this command again.", ephemeral: true });
    }
    guildRoleConfig.set(interaction.guildId, role.id);
    return interaction.reply({ content: `Verification role set to ${role}. Members can now use /verfie. Note: this starter forgets settings when the bot restarts.`, ephemeral: true });
  }

  if (interaction.commandName === "verfie") {
    if (!guildRoleConfig.has(interaction.guildId)) {
      return interaction.reply({ content: "An admin must first run /setup-verfie and choose the verification role.", ephemeral: true });
    }
    const state = crypto.randomBytes(32).toString("base64url");
    pending.set(state, { discordUserId: interaction.user.id, guildId: interaction.guildId, createdAt: Date.now() });
    const link = new URL("/verify", process.env.BASE_URL);
    link.searchParams.set("state", state);
    const embed = new EmbedBuilder().setColor(0xf0bf55)
      .setTitle("NAFL LINK — Roblox Verification")
      .setDescription("Press the button, sign in on the official Roblox page, and approve profile access. The server role will then be assigned automatically.")
      .addFields({ name: "Security", value: "NAFL LINK never asks for or stores your Roblox password." })
      .setFooter({ text: "NAFL HUB • Secure account linking" });
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel("Link Roblox Account").setStyle(ButtonStyle.Link).setURL(link.toString()).setEmoji("🔗")
    );
    return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  }
});
client.login(process.env.DISCORD_TOKEN);
